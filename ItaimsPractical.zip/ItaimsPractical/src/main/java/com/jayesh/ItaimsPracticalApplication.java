package com.jayesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItaimsPracticalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItaimsPracticalApplication.class, args);
	}
	
	

}
